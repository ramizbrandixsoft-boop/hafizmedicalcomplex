# HAFIZ Medical Complex — Website

Next.js 16 · React 19 · Tailwind 4 · PostgreSQL (Drizzle ORM)

Public site (doctors, specialties, services, gallery, patient guide, contact) plus online
appointment requests and a staff dashboard at `/admin`.

---

## 1. Run locally

```bash
npm install
cp .env.example .env.local     # then fill in the values (all optional for a first look)
npm run dev                    # http://localhost:3000
```

**The site works with no environment variables at all** — every public page renders from the
built-in content. You only need the variables below to *save* appointment requests / enquiries
and to use the staff dashboard.

## 2. Environment variables

| Variable | Needed for | Notes |
|---|---|---|
| `DATABASE_URL` | Saving appointments, enquiries, dashboard edits | Free Postgres from [Neon](https://neon.tech) or [Supabase](https://supabase.com). Use the **pooled** connection string and keep `?sslmode=require`. |
| `ADMIN_PASSWORD` | Staff login at `/admin` | At least **12** characters. |
| `ADMIN_SESSION_SECRET` | Staff login at `/admin` | At least **32** random characters. Generate: `openssl rand -hex 32` |
| `NEXT_PUBLIC_SITE_URL` | SEO / sitemap / social previews | e.g. `https://yourdomain.com` (no trailing slash). Falls back to the Vercel / Netlify URL automatically. |

Tables are **created automatically** the first time the app connects to the database —
there is no migration step. (`npm run db:push` also works if you prefer drizzle-kit.)

## 3. Deploy on Vercel (free)

1. Push this folder to a GitHub repository.
2. On [vercel.com](https://vercel.com) → **Add New → Project** → import the repo. Framework is detected as Next.js.
3. Under **Environment Variables** add `DATABASE_URL`, `ADMIN_PASSWORD`, `ADMIN_SESSION_SECRET` (and optionally `NEXT_PUBLIC_SITE_URL`).
4. Click **Deploy**.

## 4. Deploy on Netlify (free)

1. Push this folder to a GitHub repository.
2. On [netlify.com](https://netlify.com) → **Add new site → Import an existing project** → pick the repo.
3. Build command `npm run build` (already set in `netlify.toml`). Netlify's Next.js support is applied automatically — leave the publish directory empty.
4. **Site configuration → Environment variables**: add the same variables as above, then deploy.

## 5. After deploying — checklist

- Open `https://your-site/api/health` → should show `{"ok":true,"database":"connected"}`.
- Submit a test appointment request on `/appointments`, then sign in at `/admin` to see it.
- Replace the placeholder images in `public/images/` (see below).
- Check phone / WhatsApp / email / map link in **Admin → Site Details**.

## 6. Images

`public/images/*.jpg` are **branded placeholder graphics** (the original upload did not include
the image folder). Replace any file with a real photo using the **same filename** and it appears
everywhere automatically. Recommended size ~1536×1024 px, JPG, under 400 KB.
Only present photos of the real hospital/staff as such; the site labels placeholders as
illustrative until you do.

## 7. Staff dashboard (`/admin`)

Appointment requests and enquiries (with status), doctor profiles and visiting schedules,
specialties, services, gallery images and contact details. Doctor schedule changes immediately
control which dates/times patients can request. Public pages pick up edits within ~20 seconds.

## Useful scripts

```bash
npm run dev         # development server
npm run build       # production build
npm run start       # run the production build
npm run lint        # ESLint
npm run typecheck   # TypeScript
```
