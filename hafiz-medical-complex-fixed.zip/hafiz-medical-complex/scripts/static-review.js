/* Client-review behavior for the static snapshots. No patient data is stored or sent to this host. */
(() => {
  const get = (id) => document.getElementById(id);
  const text = (element) => element?.textContent?.trim() || "";

  function setupMenu() {
    const header = document.querySelector(".site-header");
    const button = document.querySelector(".menu-toggle");
    if (!header || !button) return;
    const original = button.innerHTML;
    let menu = null;
    button.addEventListener("click", () => {
      if (menu) {
        menu.remove(); menu = null; button.innerHTML = original;
        button.setAttribute("aria-expanded", "false"); button.setAttribute("aria-label", "Open menu");
        return;
      }
      menu = document.createElement("nav");
      menu.className = "mobile-menu"; menu.id = "mobile-menu";
      menu.setAttribute("aria-label", "Mobile navigation");
      const inner = document.createElement("div"); inner.className = "container-site";
      document.querySelectorAll(".desktop-nav a").forEach((link) => {
        const copy = link.cloneNode(true); copy.className = "mobile-link";
        copy.addEventListener("click", () => { if (menu) menu.remove(); menu = null; button.innerHTML = original; button.setAttribute("aria-expanded", "false"); });
        inner.appendChild(copy);
      });
      const guide = document.createElement("a"); guide.href = "/patient-guide.html";
      guide.className = "mobile-link"; guide.textContent = "Patient Guide & FAQs"; inner.appendChild(guide);
      const book = document.createElement("a"); book.href = "/appointments.html";
      book.className = "btn btn-primary mobile-book"; book.textContent = "Book an Appointment"; inner.appendChild(book);
      menu.appendChild(inner); header.appendChild(menu); button.innerHTML = "✕";
      button.setAttribute("aria-expanded", "true"); button.setAttribute("aria-label", "Close menu");
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && menu) { menu.remove(); menu = null; button.innerHTML = original; button.setAttribute("aria-expanded", "false"); }
    });
  }

  function showFormNotice(form, heading, message, link, linkLabel) {
    form.querySelector(".demo-form-feedback")?.remove();
    const box = document.createElement("div"); box.className = "demo-form-feedback";
    box.setAttribute("role", "status");
    const title = document.createElement("strong"); title.textContent = heading;
    const description = document.createElement("p"); description.textContent = message;
    box.append(title, description);
    if (link) { const anchor = document.createElement("a"); anchor.href = link; anchor.target = "_blank"; anchor.rel = "noopener noreferrer"; anchor.textContent = linkLabel; box.appendChild(anchor); }
    form.querySelector(".form-submit-row")?.before(box);
    box.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  function setupSafeForms() {
    document.querySelectorAll("form.form-card").forEach((form) => {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        const isAppointment = location.pathname.includes("appointments");
        if (isAppointment) {
          const patient = get("patient-name")?.value?.trim() || "";
          const phone = get("patient-phone")?.value?.trim() || "";
          const doctor = get("book-doctor")?.selectedOptions?.[0]?.textContent || "";
          const specialty = get("book-specialty")?.selectedOptions?.[0]?.textContent || "";
          const date = get("book-date")?.value || "";
          const time = get("book-time")?.value || "";
          const message = `Hello HAFIZ Medical Complex, I would like to request an appointment.\nPatient: ${patient}\nDoctor: ${doctor}\nSpecialty: ${specialty}\nPreferred date: ${date}\nPreferred time: ${time}\nContact: ${phone}\nPlease confirm availability.`;
          showFormNotice(form, "This is a design preview — no request was saved.", "To request a real appointment, please send these details to the hospital on WhatsApp or call +92 332 3338726. Do not treat this form as a confirmed booking.", `https://wa.me/923323338726?text=${encodeURIComponent(message)}`, "Continue on WhatsApp ↗");
        } else {
          showFormNotice(form, "This is a design preview — no enquiry was sent.", "The static review site does not store contact messages. Please email hmcdaska@gmail.com or call +92 332 3338726 instead.", "mailto:hmcdaska@gmail.com", "Email the hospital ↗");
        }
      });
    });
  }

  function setupQuickAppointment(doctors) {
    const specialty = get("quick-specialty"); const doctor = get("quick-doctor");
    if (!specialty || !doctor) return;
    specialty.addEventListener("change", () => {
      doctor.value = "";
      [...doctor.options].forEach((option) => { if (!option.value) return; const match = doctors.find((item) => item.slug === option.value); option.hidden = Boolean(specialty.value && !match?.specialtySlugs.includes(specialty.value)); });
    });
    const button = specialty.closest(".quick-card")?.querySelector("button");
    button?.addEventListener("click", () => {
      const query = new URLSearchParams(); if (specialty.value) query.set("specialty", specialty.value); if (doctor.value) query.set("doctor", doctor.value);
      location.href = `/appointments.html${query.size ? `?${query}` : ""}`;
    });
  }

  function setupDirectory(doctors) {
    const directory = document.querySelector(".directory-toolbar");
    if (!directory) return;
    const parent = directory.parentElement;
    const grid = parent?.querySelector(".doctor-grid");
    if (!grid) return;
    const cards = [...grid.querySelectorAll(".doctor-card")];
    const query = directory.querySelector('input[type="search"]');
    const selects = directory.querySelectorAll("select");
    const specialty = selects[0], day = selects[1];
    const result = parent.querySelector(".directory-results");
    const empty = document.createElement("div"); empty.className = "empty-state";
    empty.textContent = "No matching doctors in this view. Try another search or browse the full directory.";
    empty.hidden = true; grid.after(empty);
    const update = () => {
      let count = 0;
      cards.forEach((card) => {
        const href = card.querySelector("h3 a")?.getAttribute("href") || "";
        const slug = href.match(/doctors--(.+)\.html/)?.[1];
        const entry = doctors.find((item) => item.slug === slug);
        const search = query?.value?.trim().toLowerCase() || "";
        const matchesText = !search || card.textContent.toLowerCase().includes(search);
        const matchesSpecialty = !specialty?.value || entry?.specialtySlugs.includes(specialty.value);
        const matchesDay = !day?.value || (day.value === "unconfirmed" ? !entry?.schedule.confirmed : entry?.schedule.days.includes(Number(day.value)));
        const visible = matchesText && matchesSpecialty && matchesDay;
        card.hidden = !visible; card.style.display = visible ? "" : "none"; if (visible) count++;
      });
      if (result) result.textContent = `${count} ${count === 1 ? "doctor" : "doctors"} shown${cards.length < doctors.length ? " in this preview. View all doctors for the complete directory." : "."}`;
      empty.hidden = count > 0;
    };
    query?.addEventListener("input", update); specialty?.addEventListener("change", update); day?.addEventListener("change", update); update();
  }

  function setupBookingSelections(doctors) {
    const specialty = get("book-specialty"), doctor = get("book-doctor"), date = get("book-date"), time = get("book-time");
    if (!specialty || !doctor || !date || !time) return;
    const preview = document.querySelector(".schedule-preview");
    const updateDoctor = () => {
      const selected = doctors.find((item) => item.slug === doctor.value);
      date.disabled = !selected; time.disabled = !selected || !date.value;
      if (preview) preview.textContent = selected ? `${selected.name}: ${selected.schedule.label}. ${selected.schedule.confirmed ? "Choose a published visiting day. This preview does not reserve a time." : "Please contact the hospital to confirm availability."}` : "Select a doctor to see their published visiting schedule.";
      if (selected?.schedule.confirmed) { time.min = selected.schedule.start; time.max = selected.schedule.end; }
      else { time.removeAttribute("min"); time.removeAttribute("max"); }
    };
    specialty.addEventListener("change", () => {
      doctor.value = ""; date.value = ""; time.value = "";
      [...doctor.options].forEach((option) => { if (!option.value) return; const item = doctors.find((entry) => entry.slug === option.value); option.hidden = Boolean(specialty.value && !item?.specialtySlugs.includes(specialty.value)); });
      updateDoctor();
    });
    doctor.addEventListener("change", () => {
      const selected = doctors.find((item) => item.slug === doctor.value);
      if (selected && !specialty.value) { specialty.value = selected.specialtySlugs[0]; specialty.dispatchEvent(new Event("change")); doctor.value = selected.slug; }
      date.value = ""; time.value = ""; updateDoctor();
    });
    date.addEventListener("change", () => {
      const selected = doctors.find((item) => item.slug === doctor.value);
      if (selected?.schedule.confirmed && date.value) {
        const day = new Date(`${date.value}T12:00:00Z`).getUTCDay();
        if (!selected.schedule.days.includes(day)) { date.value = ""; alert("This doctor does not have published visiting hours on that day. Please choose another date."); }
      }
      time.disabled = !date.value;
    });
    const params = new URLSearchParams(location.search);
    const requestedDoctor = doctors.find((item) => item.slug === params.get("doctor"));
    if (requestedDoctor) { specialty.value = params.get("specialty") && requestedDoctor.specialtySlugs.includes(params.get("specialty")) ? params.get("specialty") : requestedDoctor.specialtySlugs[0]; specialty.dispatchEvent(new Event("change")); doctor.value = requestedDoctor.slug; }
    else if (params.get("specialty")) { specialty.value = params.get("specialty"); specialty.dispatchEvent(new Event("change")); }
    updateDoctor();
  }

  function setupGallery() {
    const buttons = [...document.querySelectorAll(".filter-pill")];
    const items = [...document.querySelectorAll(".gallery-item")];
    if (!buttons.length || !items.length) return;
    buttons.forEach((button) => button.addEventListener("click", () => {
      buttons.forEach((item) => { item.classList.toggle("active", item === button); item.setAttribute("aria-pressed", String(item === button)); });
      const category = text(button);
      items.forEach((item) => { const itemCategory = text(item.querySelector(".gallery-info span")); item.hidden = category !== "All Photos" && itemCategory !== category; item.style.display = item.hidden ? "none" : ""; });
    }));
    items.forEach((item) => item.addEventListener("click", () => {
      const image = item.querySelector("img"); if (!image) return;
      const overlay = document.createElement("div"); overlay.className = "lightbox-backdrop";
      overlay.setAttribute("role", "dialog"); overlay.setAttribute("aria-modal", "true"); overlay.setAttribute("aria-label", text(item.querySelector("h3")));
      const content = document.createElement("div"); content.className = "lightbox-content";
      const larger = document.createElement("img"); larger.src = image.src; larger.alt = image.alt;
      const caption = document.createElement("p"); caption.textContent = text(item.querySelector("h3"));
      const note = document.createElement("small"); note.textContent = "Illustrative placeholder — not the hospital, its doctors or facilities.";
      const close = document.createElement("button"); close.type = "button"; close.className = "lightbox-close"; close.textContent = "✕"; close.setAttribute("aria-label", "Close image");
      const dismiss = () => { overlay.remove(); document.body.style.overflow = ""; document.removeEventListener("keydown", keydown); };
      const keydown = (event) => { if (event.key === "Escape") dismiss(); };
      close.addEventListener("click", dismiss); overlay.addEventListener("click", (event) => { if (event.target === overlay) dismiss(); });
      content.append(larger, caption, note); overlay.append(content, close); document.body.appendChild(overlay); document.body.style.overflow = "hidden"; document.addEventListener("keydown", keydown); close.focus();
    }));
  }

  document.addEventListener("DOMContentLoaded", () => {
    setupMenu(); setupSafeForms(); setupGallery();
    fetch("/demo-data.json").then((response) => response.json()).then((data) => {
      setupQuickAppointment(data.doctors); setupDirectory(data.doctors); setupBookingSelections(data.doctors);
    }).catch(() => {});
  });
})();
