import { defineConfig } from "drizzle-kit";

// Only needed if you prefer `npm run db:push`. The app also creates its tables automatically.
export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  dbCredentials: { url: process.env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/app_db" },
});
