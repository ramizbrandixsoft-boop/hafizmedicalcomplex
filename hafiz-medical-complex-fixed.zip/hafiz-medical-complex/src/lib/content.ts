export const hospital = {
  name: "HAFIZ Medical Complex",
  tagline: "Quality Healthcare, Compassionate Care.",
  address: "Milad Chowk, College Road, Daska, 51010, Punjab, Pakistan",
  shortAddress: "Milad Chowk, College Road, Daska",
  phone: "+92 332 3338726",
  phoneHref: "tel:+923323338726",
  helpline: "042-34500888",
  helplineHref: "tel:04234500888",
  whatsapp: "923323338726",
  email: "hmcdaska@gmail.com",
  mapUrl: "https://maps.app.goo.gl/b7pJ3t7kCP1k1nsN6",
  mapEmbed: "https://www.google.com/maps?q=32.332399,74.354545&z=16&output=embed",
  instagram: "https://www.instagram.com/hafizmedicalcomplex/",
  instagramHandle: "@hafizmedicalcomplex",
  hours: "Open 24 hours",
  rating: "5.0",
  reviewCount: 33,
};

export type Schedule = {
  label: string;
  days: number[];
  start: string;
  end: string;
  confirmed: boolean;
};

export type Doctor = {
  slug: string;
  name: string;
  specialty: string;
  specialtySlugs: string[];
  initials: string;
  summary: string;
  introduction: string;
  expertise: string[];
  conditions: string[];
  schedule: Schedule;
  qualification?: string;
  alsoKnownAs?: string;
  featured?: boolean;
  image?: string;
};

export type FAQ = { question: string; answer: string };

export type Specialty = {
  slug: string;
  title: string;
  shortTitle: string;
  description: string;
  introduction: string;
  conditions: string[];
  care: string[];
  faqs: FAQ[];
  icon: string;
  image: string;
};

export type ServiceEntry = {
  id: string;
  title: string;
  description: string;
  type: "consultation" | "diagnostic";
  status: "listed" | "unconfirmed";
  published: boolean;
  specialtySlug?: string;
};

export type GalleryEntry = {
  id: string;
  title: string;
  category: string;
  image: string;
  alt: string;
  placeholder: boolean;
  published: boolean;
};

export type SiteSettings = {
  phone: string;
  helpline: string;
  whatsapp: string;
  email: string;
  address: string;
  mapUrl: string;
  instagram: string;
  facebook: string;
  youtube: string;
  tiktok: string;
  linkedin: string;
};

export const defaultSettings: SiteSettings = {
  phone: hospital.phone,
  helpline: hospital.helpline,
  whatsapp: hospital.whatsapp,
  email: hospital.email,
  address: hospital.address,
  mapUrl: hospital.mapUrl,
  instagram: hospital.instagram,
  facebook: "",
  youtube: "",
  tiktok: "",
  linkedin: "",
};

export const doctors: Doctor[] = [
  {
    slug: "dr-salman-younas",
    name: "Dr. Salman Younas",
    specialty: "General Physician / Surgeon",
    specialtySlugs: ["general-medicine", "general-laparoscopic-surgery"],
    initials: "SY",
    summary: "General medical consultations, initial health assessments and surgical consultations.",
    introduction: "Dr. Salman Younas provides a first point of contact for general health concerns, medical assessment and questions that may require a surgical opinion. A consultation can help clarify symptoms and guide appropriate next steps.",
    expertise: ["General medical consultations", "Initial health assessments", "Fever and common illnesses", "Blood pressure and routine health concerns", "Surgical consultations", "Referral guidance where appropriate"],
    conditions: ["Fever and infections", "General aches and symptoms", "Blood pressure concerns", "Ongoing health complaints", "Conditions that may need surgical assessment"],
    schedule: { label: "Daily · 5:00 PM – 10:00 PM", days: [0, 1, 2, 3, 4, 5, 6], start: "17:00", end: "22:00", confirmed: true },
    featured: true,
  },
  {
    slug: "dr-junaid-mubashir-cheema",
    name: "Dr. Junaid Mubashir Cheema",
    specialty: "General & Laparoscopic Surgeon",
    specialtySlugs: ["general-laparoscopic-surgery"],
    initials: "JC",
    summary: "Consultation for general surgical conditions and minimally invasive laparoscopic surgery.",
    introduction: "Dr. Junaid Mubashir Cheema assesses general surgical conditions and discusses treatment options, including whether a minimally invasive laparoscopic approach may be suitable. The hospital can confirm available procedures and visiting times before your visit.",
    expertise: ["General surgical consultations", "Hernia assessment", "Gallbladder-related surgical consultation", "Appendix-related surgical consultation", "Piles assessment", "Laparoscopic surgical procedures"],
    conditions: ["Hernia-related symptoms", "Gallbladder concerns", "Suspected appendix problems", "Piles and related discomfort", "Other concerns requiring a surgical opinion"],
    schedule: { label: "Contact hospital to confirm", days: [], start: "", end: "", confirmed: false },
    featured: false,
  },
  {
    slug: "dr-ayaz-ali",
    name: "Dr. Ayaz Ali",
    specialty: "Medical Specialist",
    specialtySlugs: ["general-medicine"],
    initials: "AA",
    summary: "Assessment of internal medicine conditions, chronic illnesses and complex medical complaints.",
    introduction: "Dr. Ayaz Ali provides medical consultations for people living with persistent symptoms or conditions that need a broader internal medicine assessment. A visit can help review concerns, existing reports and a suitable care plan.",
    expertise: ["Internal medicine consultation", "Chronic illness assessment", "Complex medical complaints", "Review of ongoing symptoms", "General medical follow-up"],
    conditions: ["Persistent or unexplained symptoms", "Chronic health conditions", "Blood pressure concerns", "General internal medicine concerns"],
    schedule: { label: "Tuesday – Wednesday · 4:00 PM – 7:00 PM", days: [2, 3], start: "16:00", end: "19:00", confirmed: true },
  },
  {
    slug: "dr-raja-sheraz-ullah-khan",
    name: "Asst. Prof. Dr. Raja Sheraz Ullah Khan",
    alsoKnownAs: "Dr. Sheraz Ullah",
    specialty: "Endocrinologist / Diabetes Specialist",
    specialtySlugs: ["endocrinology-diabetes"],
    initials: "SK",
    summary: "Specialist consultations for diabetes, thyroid, hormonal and chronic disease concerns.",
    introduction: "Asst. Prof. Dr. Raja Sheraz Ullah Khan offers focused consultations for diabetes and endocrine health. Whether you are managing blood sugar over time or have questions about thyroid, hormones or weight-related concerns, a consultation can help you understand your condition and next steps.",
    expertise: ["Type 1 diabetes", "Type 2 diabetes", "Diabetes management", "High blood pressure", "Thyroid disorders", "Obesity management", "Hormonal disorders", "Chronic disease management", "Complicated diabetes cases"],
    conditions: ["High or fluctuating blood sugar", "Type 1 and Type 2 diabetes", "Thyroid-related symptoms", "Hormonal imbalance concerns", "Weight and metabolic concerns", "Long-term health conditions"],
    schedule: { label: "Monday & Thursday · 2:00 PM – 4:00 PM", days: [1, 4], start: "14:00", end: "16:00", confirmed: true },
    featured: true,
  },
  {
    slug: "dr-izam-afzal",
    name: "Dr. Izam Afzal",
    specialty: "Obstetrician & Gynaecologist",
    specialtySlugs: ["gynecology-obstetrics"],
    initials: "IA",
    summary: "Respectful consultations for women's health, pregnancy and gynaecological concerns.",
    introduction: "Dr. Izam Afzal provides sensitive, patient-centred consultations across women's reproductive health and pregnancy care. Patients can discuss symptoms, ask questions and seek guidance on appropriate assessment and follow-up.",
    expertise: ["Women's reproductive health", "Pregnancy consultations", "Antenatal care", "Menstrual irregularities", "PCOS assessment", "Hormonal concerns", "Menopause-related consultations", "General gynaecological examinations", "Infertility assessment"],
    conditions: ["Menstrual irregularities", "Pregnancy-related questions", "Possible PCOS symptoms", "Menopause concerns", "Fertility questions", "Other gynaecological symptoms"],
    schedule: { label: "Monday – Saturday · 4:00 PM – 7:00 PM", days: [1, 2, 3, 4, 5, 6], start: "16:00", end: "19:00", confirmed: true },
    featured: true,
  },
  {
    slug: "dr-idrees-khan-zai",
    name: "Dr. Idrees Khan Zai",
    specialty: "Gastroenterologist",
    specialtySlugs: ["gastroenterology"],
    initials: "IK",
    summary: "Consultations for digestive discomfort, reflux, bowel symptoms and liver-related concerns.",
    introduction: "Dr. Idrees Khan Zai offers specialist assessment for digestive health concerns. Discuss ongoing stomach or bowel symptoms, their possible causes and suitable next steps during a consultation.",
    expertise: ["Acidity", "Acid reflux", "Gastritis", "Abdominal discomfort", "Digestive disorders", "Constipation", "Diarrhoea", "Irritable bowel symptoms", "Liver and digestive health concerns"],
    conditions: ["Heartburn and acid reflux", "Gastritis-like symptoms", "Abdominal pain or discomfort", "Changes in bowel habits", "Liver-related concerns"],
    schedule: { label: "Saturday – Sunday · 2:00 PM – 4:00 PM", days: [6, 0], start: "14:00", end: "16:00", confirmed: true },
  },
  {
    slug: "dr-sufyan-saeed",
    name: "Dr. Sufyan Saeed",
    specialty: "Dermatologist",
    specialtySlugs: ["dermatology"],
    initials: "SS",
    summary: "Consultations for skin, hair and common dermatological concerns.",
    introduction: "Dr. Sufyan Saeed assesses a range of skin and hair concerns, helping patients understand symptoms and discuss an appropriate care approach for their individual needs.",
    expertise: ["Acne", "Skin allergies", "Eczema", "Skin infections", "Hair loss", "Dandruff", "Pigmentation", "General skin conditions"],
    conditions: ["Acne and breakouts", "Itchy or irritated skin", "Eczema-like rashes", "Skin infections", "Hair fall and scalp concerns", "Pigmentation changes"],
    schedule: { label: "Monday – Thursday · 2:00 PM – 5:00 PM", days: [1, 2, 3, 4], start: "14:00", end: "17:00", confirmed: true },
  },
  {
    slug: "dr-hasib-hasnat",
    name: "Dr. Hasib Hasnat",
    specialty: "ENT Specialist",
    specialtySlugs: ["ent"],
    initials: "HH",
    summary: "Assessment of ear, nose, sinus, throat, hearing and voice complaints.",
    introduction: "Dr. Hasib Hasnat provides ENT consultations for symptoms affecting the ears, nose and throat. An assessment can help identify the nature of a concern and guide appropriate treatment or further evaluation.",
    expertise: ["Ear disorders", "Nose and sinus problems", "Throat infections", "Tonsil-related concerns", "Hearing-related complaints", "Voice and throat conditions"],
    conditions: ["Ear pain or discomfort", "Sinus and nasal symptoms", "Sore throat and tonsil concerns", "Hearing difficulties", "Voice changes"],
    schedule: { label: "Wednesday – Thursday · 12:00 PM – 3:00 PM", days: [3, 4], start: "12:00", end: "15:00", confirmed: true },
  },
  {
    slug: "hammad-raza-mustafai",
    name: "Hammad Raza Mustafai",
    specialty: "Audiologist",
    specialtySlugs: ["audiology"],
    initials: "HM",
    qualification: "BS Audiology, MS Audiology/SLP",
    summary: "Hearing assessments and guidance for hearing-related difficulties.",
    introduction: "Hammad Raza Mustafai provides audiology-focused consultations for hearing concerns. Patients can ask about assessment, hearing loss, tinnitus and rehabilitation options. Please confirm specific testing and hearing-aid services with the hospital first.",
    expertise: ["Hearing assessments", "Hearing loss evaluation", "Hearing-related difficulties", "Tinnitus assessment", "Hearing aid consultation and fitting (subject to confirmation)", "Audiological rehabilitation"],
    conditions: ["Difficulty hearing conversations", "Ringing or buzzing in the ears", "Suspected hearing loss", "Questions about hearing support"],
    schedule: { label: "Contact hospital to confirm", days: [], start: "", end: "", confirmed: false },
  },
  {
    slug: "consultant-psychiatrist",
    name: "Consultant Psychiatrist",
    specialty: "Psychiatry / Mental Health",
    specialtySlugs: ["psychiatry"],
    initials: "MH",
    summary: "Mental health consultations; please contact the hospital for the consultant's name and availability.",
    introduction: "The hospital lists psychiatry and mental health consultation. You can contact the appointment team to confirm the consultant's name, availability and an appropriate time for a private conversation about your concerns.",
    expertise: ["Anxiety", "Depression", "Stress", "Sleep-related concerns", "Mood disorders", "Mental health assessments"],
    conditions: ["Persistent anxiety or worry", "Low mood", "Ongoing stress", "Sleep difficulties", "Changes in mood"],
    schedule: { label: "Contact hospital for availability", days: [], start: "", end: "", confirmed: false },
  },
];

export const specialties: Specialty[] = [
  {
    slug: "general-medicine", title: "General Medicine & Family Care", shortTitle: "General Medicine", icon: "stethoscope", image: "/images/family-south-asian.jpg",
    description: "Thoughtful first-line care for everyday health concerns and ongoing medical needs.",
    introduction: "General medicine helps you understand new symptoms, monitor existing conditions and decide on the right next step for your health. Our listed general and medical specialists provide consultations for a broad range of concerns in Daska.",
    conditions: ["Fever and infections", "General medical assessment", "Blood pressure concerns", "Diabetes screening and consultation", "Chronic illnesses", "General health concerns"],
    care: ["Discuss symptoms and medical history", "Review existing test reports when available", "Understand appropriate follow-up or specialist referral"],
    faqs: [{ question: "When should I see a general physician?", answer: "A general physician is a good starting point for a new symptom, persistent discomfort or an ongoing health concern." }, { question: "Can I discuss blood pressure or diabetes?", answer: "Yes. A consultation can help assess concerns and guide appropriate monitoring or specialist care." }],
  },
  {
    slug: "general-laparoscopic-surgery", title: "General & Laparoscopic Surgery", shortTitle: "General Surgery", icon: "activity", image: "/images/surgery-south-asian.jpg",
    description: "Surgical opinions and guidance on suitable treatment options, including laparoscopy.",
    introduction: "A surgical consultation is an opportunity to discuss symptoms, review findings and understand whether further tests, a procedure or another treatment approach may be appropriate. Procedure availability should be confirmed with the hospital.",
    conditions: ["General surgical consultations", "Hernia assessment", "Gallbladder-related conditions", "Appendix-related conditions", "Piles assessment", "Minimally invasive surgery discussion"],
    care: ["Understand the concern and available treatment paths", "Discuss whether minimally invasive surgery may be suitable", "Confirm procedure arrangements directly with the hospital"],
    faqs: [{ question: "Does everyone need surgery after a consultation?", answer: "No. A surgeon first assesses your condition and discusses the most suitable next steps." }, { question: "Is laparoscopic surgery available for my condition?", answer: "Suitability and procedure availability depend on clinical assessment and hospital confirmation. Please contact the hospital for details." }],
  },
  {
    slug: "endocrinology-diabetes", title: "Endocrinology & Diabetes Care", shortTitle: "Endocrinology", icon: "droplets", image: "/images/diabetes-south-asian.jpg",
    description: "Specialist attention for diabetes, thyroid, hormonal and metabolic health.",
    introduction: "Endocrinology focuses on hormones and metabolic health. Specialist consultations can help you understand blood sugar patterns, thyroid concerns and other hormonal or long-term conditions, and discuss an individual care plan.",
    conditions: ["Type 1 diabetes", "Type 2 diabetes", "Blood sugar management", "Thyroid disorders", "Hormonal imbalances", "Obesity and metabolic conditions"],
    care: ["Review symptoms, history and relevant reports", "Discuss diabetes management and follow-up", "Address thyroid, hormonal and metabolic concerns"],
    faqs: [{ question: "Can I seek help for difficult-to-manage diabetes?", answer: "Yes. The listed endocrinologist consults on diabetes management, including complicated cases." }, { question: "Should I bring my blood sugar readings?", answer: "If you have readings, medicines or previous reports, bringing them may help the specialist understand your history." }],
  },
  {
    slug: "gynecology-obstetrics", title: "Gynaecology & Obstetrics", shortTitle: "Women's Health", icon: "heart", image: "/images/womens-south-asian.jpg",
    description: "Sensitive, supportive care for reproductive health and pregnancy questions.",
    introduction: "Women's health concerns deserve a respectful space to ask questions and receive guidance. Gynaecology and obstetrics consultations cover reproductive health, pregnancy-related care and assessment of symptoms at different life stages.",
    conditions: ["Women's reproductive health", "Pregnancy consultations and antenatal care", "Menstrual problems", "PCOS assessment", "Hormonal concerns", "Menopause", "Infertility assessment"],
    care: ["Discuss concerns in a respectful consultation", "Review pregnancy or reproductive health questions", "Understand suitable assessment and follow-up"],
    faqs: [{ question: "Can I book for menstrual irregularities?", answer: "Yes. A gynaecology consultation can help assess changes in your cycle and related concerns." }, { question: "Can I ask about pregnancy care?", answer: "Yes. Pregnancy consultations and antenatal care are among the listed consultation areas." }],
  },
  {
    slug: "gastroenterology", title: "Gastroenterology", shortTitle: "Gastroenterology", icon: "scan", image: "/images/asian-senior-consult.jpg",
    description: "Expert assessment for stomach, bowel and digestive health concerns.",
    introduction: "Digestive symptoms can affect daily life. Gastroenterology consultations help assess persistent stomach, bowel or liver-related concerns and discuss appropriate next steps.",
    conditions: ["Digestive health", "Gastritis and acidity", "Acid reflux", "Abdominal complaints", "Bowel disorders", "Liver-related concerns"],
    care: ["Discuss patterns of digestive symptoms", "Review relevant previous reports", "Plan appropriate assessment or follow-up"],
    faqs: [{ question: "When should I consult a gastroenterologist?", answer: "Consider a specialist consultation for recurring reflux, ongoing abdominal discomfort or changes in bowel habits." }, { question: "Can I bring previous test results?", answer: "Yes. Previous reports can be useful context for your consultation." }],
  },
  {
    slug: "dermatology", title: "Dermatology", shortTitle: "Dermatology", icon: "sparkles", image: "/images/skin-south-asian.jpg",
    description: "Considerate consultations for skin, scalp, hair and nail concerns.",
    introduction: "Dermatology addresses conditions affecting the skin, hair and nails. A consultation can help you understand a persistent concern and discuss care options suited to your needs.",
    conditions: ["Acne", "Skin allergies", "Eczema", "Skin infections", "Hair loss", "Pigmentation", "Hair and nail health"],
    care: ["Assess visible changes and symptoms", "Discuss skin and scalp care questions", "Understand suitable treatment or follow-up"],
    faqs: [{ question: "Can I consult about hair loss?", answer: "Yes. Hair loss and scalp concerns are among the listed consultation areas." }, { question: "Should I bring my current skin products?", answer: "A list or photos of products and medications you use can help provide context." }],
  },
  {
    slug: "ent", title: "ENT (Ear, Nose & Throat)", shortTitle: "ENT", icon: "ear", image: "/images/hearing-south-asian.jpg",
    description: "Focused attention for ear, sinus, throat, hearing and voice complaints.",
    introduction: "ENT care evaluates symptoms affecting the ears, nose, sinuses and throat. An ENT consultation can help clarify your concerns and whether further assessment is needed.",
    conditions: ["Ear disorders", "Nose and sinus issues", "Throat infections", "Tonsil concerns", "Hearing complaints", "Voice-related concerns"],
    care: ["Discuss the history of symptoms", "Assess ear, nose or throat complaints", "Consider whether hearing evaluation is appropriate"],
    faqs: [{ question: "Can I visit for recurring sinus symptoms?", answer: "Yes. Nose and sinus concerns are included in ENT consultations." }, { question: "Who should I see for hearing difficulty?", answer: "An ENT specialist or audiologist may be appropriate, depending on the concern. Call the hospital for guidance." }],
  },
  {
    slug: "audiology", title: "Audiology & Hearing Care", shortTitle: "Audiology", icon: "audio", image: "/images/hearing-south-asian.jpg",
    description: "Hearing-focused guidance, assessments and support options.",
    introduction: "Audiology helps assess hearing-related difficulties and understand options for support. Please contact the hospital to confirm which hearing tests, hearing-aid services and rehabilitation options are currently available.",
    conditions: ["Hearing tests (confirm availability)", "Hearing loss evaluation", "Tinnitus assessment", "Hearing aid guidance (confirm availability)", "Hearing rehabilitation"],
    care: ["Discuss hearing-related difficulties", "Ask about suitable hearing assessment", "Confirm specific tests and support services before visiting"],
    faqs: [{ question: "Can I request a hearing test?", answer: "You may request an audiology consultation; please confirm the availability of specific tests with the hospital." }, { question: "Are hearing aids available?", answer: "Hearing aid consultation and fitting are subject to hospital confirmation. Call before visiting for that service." }],
  },
  {
    slug: "psychiatry", title: "Psychiatry & Mental Health", shortTitle: "Mental Health", icon: "brain", image: "/images/mental-south-asian.jpg",
    description: "A supportive starting point for conversations about mental wellbeing.",
    introduction: "Mental health concerns are health concerns. A psychiatry consultation provides space to discuss symptoms and seek an appropriate assessment. Please contact the hospital to confirm the consultant's name and schedule before booking.",
    conditions: ["Mental health assessment", "Anxiety", "Depression", "Stress", "Sleep difficulties", "Mood disorders"],
    care: ["Share concerns in a respectful setting", "Discuss symptoms and their impact on daily life", "Confirm the consultant and availability with the hospital"],
    faqs: [{ question: "Is the psychiatrist's schedule published?", answer: "No. Please contact the hospital for the consultant's name and visiting availability." }, { question: "Can I ask about sleep and mood?", answer: "Yes. Sleep-related concerns and mood changes are among the listed consultation areas." }],
  },
];

export const services: ServiceEntry[] = [
  ...specialties.map((s) => ({ id: `consult-${s.slug}`, title: s.title, description: s.description, type: "consultation" as const, status: "listed" as const, published: true, specialtySlug: s.slug })),
  { id: "consult-laparoscopic", title: "Laparoscopic Surgery Consultation", description: "Discuss whether a minimally invasive surgical approach may be suitable. Confirm procedure availability with the hospital.", type: "consultation", status: "listed", published: true, specialtySlug: "general-laparoscopic-surgery" },
  ...["Ultrasound", "Radiology", "X-ray", "MRI", "CT scan", "3D ultrasound", "4D ultrasound", "TVS ultrasound", "Sonography"].map((title) => ({ id: `diagnostic-${title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`, title, description: "Availability has not been independently confirmed. Please call the hospital before planning a visit for this service.", type: "diagnostic" as const, status: "unconfirmed" as const, published: true })),
];

export const gallery: GalleryEntry[] = [
  { id: "exterior-1", title: "Exterior image placeholder", category: "Hospital Exterior", image: "/images/exterior-placeholder.jpg", alt: "Illustrative stock building exterior, not HAFIZ Medical Complex", placeholder: true, published: true },
  { id: "interior-1", title: "A welcoming reception", category: "Hospital Interior", image: "/images/reception-south-asian.jpg", alt: "Illustrative South Asian clinic reception scene, not HAFIZ Medical Complex", placeholder: true, published: true },
  { id: "doctors-1", title: "A listening consultation", category: "Doctors", image: "/images/hero-south-asian.jpg", alt: "Illustrative South Asian doctor consulting a patient, not hospital staff", placeholder: true, published: true },
  { id: "team-1", title: "Working together in care", category: "Medical Team", image: "/images/team-south-asian.jpg", alt: "Illustrative South Asian healthcare team, not HAFIZ staff", placeholder: true, published: true },
  { id: "care-1", title: "Family care conversation", category: "Patient Care", image: "/images/family-south-asian.jpg", alt: "Illustrative South Asian family consultation, not hospital staff", placeholder: true, published: true },
  { id: "care-2", title: "Women's health consultation", category: "Patient Care", image: "/images/womens-south-asian.jpg", alt: "Illustrative South Asian women's health consultation, not hospital staff", placeholder: true, published: true },
  { id: "facility-1", title: "A place to feel welcome", category: "Facilities", image: "/images/reception-south-asian.jpg", alt: "Illustrative clinic reception, not HAFIZ Medical Complex facilities", placeholder: true, published: true },
  { id: "doctors-2", title: "Discussing treatment options", category: "Doctors", image: "/images/surgery-south-asian.jpg", alt: "Illustrative South Asian surgical consultation, not a named hospital doctor", placeholder: true, published: true },
  { id: "team-2", title: "Hearing care conversation", category: "Medical Team", image: "/images/hearing-south-asian.jpg", alt: "Illustrative South Asian hearing care discussion, not HAFIZ staff", placeholder: true, published: true },
];

export const patientFaqs: FAQ[] = [
  { question: "How can I book an appointment?", answer: "Submit an appointment request through the website, call +92 332 3338726, or send a WhatsApp message. Online requests are pending until the hospital confirms them." },
  { question: "How can I find the right specialist?", answer: "Browse the specialties or search the doctor directory by name, specialty or visiting day. If you are unsure, call the hospital for appointment assistance." },
  { question: "How can I contact the hospital?", answer: "Call +92 332 3338726, use WhatsApp on the same number, email hmcdaska@gmail.com or send a message from the contact page." },
  { question: "Where is HAFIZ Medical Complex located?", answer: "The hospital is at Milad Chowk, College Road, Daska, 51010, Punjab, Pakistan. Use the Get Directions link for Google Maps." },
  { question: "How can I check a doctor's visiting schedule?", answer: "Published visiting days and times appear on each doctor profile. Schedules can change, so please confirm with the hospital before travelling." },
  { question: "Can I request an appointment through WhatsApp?", answer: "Yes. Use a WhatsApp appointment link on the website. The message can include your preferred doctor, date and time; hospital staff will confirm availability." },
  { question: "What should I bring to my appointment?", answer: "If available, bring previous prescriptions, relevant test reports and a list of medicines you take. Call the hospital if you have questions about a particular visit." },
  { question: "How can I confirm a doctor's availability?", answer: "Please call or WhatsApp the hospital. The hospital is advertised as open 24 hours, but each doctor's consultation schedule is separate." },
  { question: "Is my online request a confirmed appointment?", answer: "No. Your reference confirms that your request was received. An appointment is only confirmed after hospital staff reviews and approves it." },
];

export const weekdayOptions = [
  { value: 1, label: "Monday" }, { value: 2, label: "Tuesday" }, { value: 3, label: "Wednesday" },
  { value: 4, label: "Thursday" }, { value: 5, label: "Friday" }, { value: 6, label: "Saturday" }, { value: 0, label: "Sunday" },
];

export const getInitials = (name: string) => name.replace(/^(Asst\. Prof\. |Dr\. )/, "").split(" ").filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
export const phoneToHref = (phone: string) => `tel:${phone.replace(/[^+\d]/g, "")}`;
export const whatsAppUrl = (message = "Hello HAFIZ Medical Complex, I would like to request an appointment.") => `https://wa.me/${hospital.whatsapp}?text=${encodeURIComponent(message)}`;
