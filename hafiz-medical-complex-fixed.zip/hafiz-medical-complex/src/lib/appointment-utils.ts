import type { Schedule } from "@/lib/content";

export function todayInPakistan() {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Karachi", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const part = (type: string) => parts.find((item) => item.type === type)?.value || "";
  return `${part("year")}-${part("month")}-${part("day")}`;
}

export function currentTimeInPakistan() {
  return new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Karachi", hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date());
}

export function validDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  const parsed = new Date(Date.UTC(year, month - 1, day));
  return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month - 1 && parsed.getUTCDate() === day;
}

export function dateWeekday(value: string) {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay();
}

export function isVisitingDay(value: string, schedule: Schedule) {
  return !schedule.confirmed || (validDate(value) && schedule.days.includes(dateWeekday(value)));
}

export function timeSlots(schedule: Schedule) {
  if (!schedule.confirmed || !schedule.start || !schedule.end) return [];
  const toMinutes = (time: string) => Number(time.split(":")[0]) * 60 + Number(time.split(":")[1]);
  const slots: string[] = [];
  for (let minutes = toMinutes(schedule.start); minutes < toMinutes(schedule.end); minutes += 30) slots.push(`${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`);
  return slots;
}

export function formatTime(value: string) {
  if (!/^\d{2}:\d{2}$/.test(value)) return value;
  const [hour, minute] = value.split(":").map(Number);
  return `${hour % 12 || 12}:${String(minute).padStart(2, "0")} ${hour >= 12 ? "PM" : "AM"}`;
}

export function formatDate(value: string) {
  if (!validDate(value)) return value;
  return new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(`${value}T12:00:00Z`));
}

export function upcomingVisitingDates(schedule: Schedule, count = 3) {
  if (!schedule.confirmed) return [];
  const today = todayInPakistan();
  const result: string[] = [];
  const start = new Date(`${today}T12:00:00Z`);
  for (let offset = 0; offset < 30 && result.length < count; offset++) {
    const current = new Date(start.getTime() + offset * 86400000);
    const date = current.toISOString().slice(0, 10);
    if (schedule.days.includes(current.getUTCDay()) && (date !== today || timeSlots(schedule).some((slot) => slot > currentTimeInPakistan()))) result.push(date);
  }
  return result;
}
