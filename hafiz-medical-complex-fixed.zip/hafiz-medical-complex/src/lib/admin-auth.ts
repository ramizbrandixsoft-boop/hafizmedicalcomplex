import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

export const ADMIN_COOKIE = "hmc_staff_session";
const SESSION_SECONDS = 60 * 60 * 24 * 7;

export function adminConfigured() {
  return Boolean(process.env.ADMIN_PASSWORD && process.env.ADMIN_PASSWORD.length >= 12 && process.env.ADMIN_SESSION_SECRET && process.env.ADMIN_SESSION_SECRET.length >= 32);
}

export function validAdminPassword(input: string) {
  if (!adminConfigured()) return false;
  const expected = createHash("sha256").update(process.env.ADMIN_PASSWORD!).digest();
  const received = createHash("sha256").update(input).digest();
  return timingSafeEqual(expected, received);
}

function sign(payload: string) {
  return createHmac("sha256", process.env.ADMIN_SESSION_SECRET || "unconfigured").update(payload).digest("hex");
}

export function createAdminSession() {
  if (!adminConfigured()) throw new Error("Admin access is not configured");
  const payload = `v1.${Math.floor(Date.now() / 1000) + SESSION_SECONDS}.${randomBytes(16).toString("hex")}`;
  return `${payload}.${sign(payload)}`;
}

export function validAdminSession(token?: string) {
  if (!adminConfigured() || !token) return false;
  const parts = token.split(".");
  if (parts.length !== 4 || parts[0] !== "v1" || !/^\d+$/.test(parts[1])) return false;
  if (Number(parts[1]) <= Math.floor(Date.now() / 1000)) return false;
  const payload = parts.slice(0, 3).join(".");
  const actual = Buffer.from(parts[3], "hex");
  const expected = Buffer.from(sign(payload), "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

export async function isAdminAuthenticated() {
  return validAdminSession((await cookies()).get(ADMIN_COOKIE)?.value);
}

export const adminCookieOptions = { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict" as const, path: "/", maxAge: SESSION_SECONDS };
