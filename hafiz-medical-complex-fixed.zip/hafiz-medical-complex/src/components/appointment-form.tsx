"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, CalendarDays, Check, Clock3, Info, MessageCircle, Phone, RotateCcw } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa6";
import { currentTimeInPakistan, formatDate, formatTime, isVisitingDay, timeSlots, todayInPakistan, upcomingVisitingDates } from "@/lib/appointment-utils";
import { phoneToHref, type Doctor, type SiteSettings, type Specialty } from "@/lib/content";

type FormState = { patientName: string; phone: string; age: string; gender: string; specialtySlug: string; doctorSlug: string; preferredDate: string; preferredTime: string; reason: string; notes: string; website: string };
type Result = { reference: string; status: string; doctorName: string; specialtyName: string; preferredDate: string; preferredTime: string };

export function AppointmentForm({ doctors, specialties, settings, defaultDoctorSlug = "", defaultSpecialtySlug = "" }: { doctors: Doctor[]; specialties: Specialty[]; settings: SiteSettings; defaultDoctorSlug?: string; defaultSpecialtySlug?: string }) {
  const initialDoctor = doctors.find((item) => item.slug === defaultDoctorSlug);
  const initialSpecialty = initialDoctor && (!defaultSpecialtySlug || !initialDoctor.specialtySlugs.includes(defaultSpecialtySlug)) ? initialDoctor.specialtySlugs[0] : defaultSpecialtySlug;
  const initial: FormState = { patientName: "", phone: "", age: "", gender: "", specialtySlug: initialSpecialty || "", doctorSlug: initialDoctor?.slug || "", preferredDate: "", preferredTime: "", reason: "", notes: "", website: "" };
  const [form, setForm] = useState<FormState>(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [dateError, setDateError] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const selectedDoctor = doctors.find((item) => item.slug === form.doctorSlug);
  const selectedSpecialty = specialties.find((item) => item.slug === form.specialtySlug);
  const relevant = form.specialtySlug ? doctors.filter((item) => item.specialtySlugs.includes(form.specialtySlug)) : doctors;
  const today = todayInPakistan();
  const availableSlots = selectedDoctor?.schedule.confirmed ? timeSlots(selectedDoctor.schedule).filter((slot) => form.preferredDate !== today || slot > currentTimeInPakistan()) : [];
  const upcoming = selectedDoctor?.schedule.confirmed ? upcomingVisitingDates(selectedDoctor.schedule) : [];
  const whatsappMessage = ["Hello HAFIZ Medical Complex, I would like to request an appointment.", `Patient name: ${form.patientName || "Not entered"}`, `Selected doctor: ${selectedDoctor?.name || "Not selected"}`, `Specialty: ${selectedSpecialty?.title || "Not selected"}`, `Requested date: ${form.preferredDate ? formatDate(form.preferredDate) : "Not selected"}`, `Requested time: ${form.preferredTime ? formatTime(form.preferredTime) : "Not selected"}`, `Contact number: ${form.phone || "Not entered"}`, "Please confirm availability. Thank you."].join("\n");
  const whatsappHref = `https://wa.me/${settings.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent(whatsappMessage)}`;
  function update(field: keyof FormState, value: string) { setForm((previous) => ({ ...previous, [field]: value })); setError(""); }
  function changeSpecialty(value: string) { setForm((previous) => ({ ...previous, specialtySlug: value, doctorSlug: "", preferredDate: "", preferredTime: "" })); setDateError(""); setError(""); }
  function changeDoctor(value: string) { const doctor = doctors.find((item) => item.slug === value); setForm((previous) => ({ ...previous, doctorSlug: value, specialtySlug: previous.specialtySlug || doctor?.specialtySlugs[0] || "", preferredDate: "", preferredTime: "" })); setDateError(""); setError(""); }
  function changeDate(value: string) {
    if (selectedDoctor && value && !isVisitingDay(value, selectedDoctor.schedule)) { setDateError(`${selectedDoctor.name} does not have published visiting hours on that day. Choose a listed visiting day.`); setForm((previous) => ({ ...previous, preferredDate: "", preferredTime: "" })); return; }
    setDateError(""); setForm((previous) => ({ ...previous, preferredDate: value, preferredTime: "" })); setError("");
  }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError("");
    if (!selectedDoctor || !selectedSpecialty) { setError("Please select a specialty and doctor."); return; }
    if (!form.preferredDate || !isVisitingDay(form.preferredDate, selectedDoctor.schedule)) { setError("Please select an available visiting date."); return; }
    if (!form.preferredTime) { setError("Please select a preferred time."); return; }
    setBusy(true);
    try {
      const response = await fetch("/api/appointments", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...form, age: Number(form.age) }) });
      const data = await response.json();
      if (!response.ok) { setError(data.error || "We could not submit the request. Please try again."); return; }
      setResult(data as Result);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch { setError("Connection problem. Please call or WhatsApp the hospital instead."); }
    finally { setBusy(false); }
  }
  if (result) {
    const confirmationMessage = `${whatsappMessage}\nAppointment request reference: ${result.reference}\nStatus: Pending hospital confirmation.`;
    const confirmationWhatsApp = `https://wa.me/${settings.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent(confirmationMessage)}`;
    return <div className="success-panel" role="status" aria-live="polite"><span className="success-icon"><Check size={28} /></span><span className="eyebrow"><span className="eyebrow-dot" /> REQUEST RECEIVED</span><h2>Thank you, {form.patientName.split(" ")[0]}.</h2><p>Your appointment <strong>request</strong> has been saved. This is <strong>not a confirmed appointment</strong>. Hospital staff must review availability and approve it before your visit.</p><div className="reference-box"><span>Your request reference</span><strong>{result.reference}</strong></div><div className="success-details"><div><small>Selected doctor</small><strong>{result.doctorName}</strong></div><div><small>Specialty</small><strong>{result.specialtyName}</strong></div><div><small>Requested date</small><strong>{formatDate(result.preferredDate)}</strong></div><div><small>Requested time</small><strong>{formatTime(result.preferredTime)}</strong></div></div><span className="status-pending"><Clock3 size={14} /> Pending hospital confirmation</span><p className="!mt-5">Please keep your reference. For a time-sensitive enquiry or to follow up, contact the hospital directly.</p><div className="success-actions"><a href={confirmationWhatsApp} target="_blank" rel="noopener noreferrer" className="btn btn-primary"><FaWhatsapp size={18} /> Send Details on WhatsApp</a><a href={phoneToHref(settings.phone)} className="btn btn-outline"><Phone size={16} /> Call Hospital</a><button type="button" className="btn btn-ghost" onClick={() => { setForm(initial); setResult(null); }}><RotateCcw size={16} /> New Request</button></div></div>;
  }
  return <form className="form-card" onSubmit={submit} noValidate={false}><h2>Request an appointment</h2><p>Fill in your details and preferred visit time. Our team will review your request; it is not confirmed until approved by hospital staff.</p><div className="form-grid">
    <div className="form-group"><label className="form-label" htmlFor="patient-name">Patient full name <span>*</span></label><input className="form-input" id="patient-name" name="patientName" autoComplete="name" placeholder="Enter your full name" required minLength={2} maxLength={160} value={form.patientName} onChange={(event) => update("patientName", event.target.value)} /></div>
    <div className="form-group"><label className="form-label" htmlFor="patient-phone">Mobile number <span>*</span></label><input className="form-input" id="patient-phone" name="phone" type="tel" autoComplete="tel" placeholder="03XX XXXXXXX" required minLength={9} value={form.phone} onChange={(event) => update("phone", event.target.value)} /></div>
    <div className="form-group"><label className="form-label" htmlFor="patient-age">Age <span>*</span></label><input className="form-input" id="patient-age" name="age" type="number" inputMode="numeric" min={1} max={120} placeholder="Age in years" required value={form.age} onChange={(event) => update("age", event.target.value)} /></div>
    <div className="form-group"><label className="form-label" htmlFor="patient-gender">Gender <span>*</span></label><select className="form-input" id="patient-gender" name="gender" required value={form.gender} onChange={(event) => update("gender", event.target.value)}><option value="">Select gender</option><option>Female</option><option>Male</option><option>Other</option><option>Prefer not to say</option></select></div>
    <div className="form-group"><label className="form-label" htmlFor="book-specialty">Medical specialty <span>*</span></label><select className="form-input" id="book-specialty" name="specialtySlug" required value={form.specialtySlug} onChange={(event) => changeSpecialty(event.target.value)}><option value="">Select a specialty</option>{specialties.map((item) => <option key={item.slug} value={item.slug}>{item.title}</option>)}</select></div>
    <div className="form-group"><label className="form-label" htmlFor="book-doctor">Preferred doctor <span>*</span></label><select className="form-input" id="book-doctor" name="doctorSlug" required value={form.doctorSlug} onChange={(event) => changeDoctor(event.target.value)}><option value="">Select a doctor</option>{relevant.map((item) => <option key={item.slug} value={item.slug}>{item.name}</option>)}</select></div>
  </div>
    {selectedDoctor ? <div className="schedule-preview"><CalendarDays size={19} /><div><strong>{selectedDoctor.name}: {selectedDoctor.schedule.label}</strong><br />{selectedDoctor.schedule.confirmed ? "Choose a date that matches the published visiting days. Hours may change; confirmation is required." : "Please contact the hospital to confirm availability. Your date and time below are preferences only."}{upcoming.length > 0 && <div className="time-chip-row">{upcoming.map((date) => <button type="button" key={date} className="time-chip" onClick={() => changeDate(date)}>{new Intl.DateTimeFormat("en-GB", { weekday: "short", day: "numeric", month: "short", timeZone: "UTC" }).format(new Date(`${date}T12:00:00Z`))}</button>)}</div>}</div></div> : <div className="schedule-preview"><Info size={18} /> Select a doctor to see their published visiting schedule.</div>}
    <div className="form-grid mt-5"><div className="form-group"><label className="form-label" htmlFor="book-date">Preferred appointment date <span>*</span></label><input className="form-input" id="book-date" name="preferredDate" type="date" min={today} required disabled={!selectedDoctor} value={form.preferredDate} onChange={(event) => changeDate(event.target.value)} />{dateError && <span className="form-error" role="alert">{dateError}</span>}<span className="form-helper">Only published visiting days can be requested for doctors with confirmed schedules.</span></div><div className="form-group"><label className="form-label" htmlFor="book-time">Preferred time <span>*</span></label>{selectedDoctor?.schedule.confirmed ? <select className="form-input" id="book-time" name="preferredTime" value={form.preferredTime} required disabled={!form.preferredDate} onChange={(event) => update("preferredTime", event.target.value)}><option value="">Choose a time</option>{availableSlots.map((slot) => <option value={slot} key={slot}>{formatTime(slot)}</option>)}</select> : <input className="form-input" id="book-time" name="preferredTime" type="time" required disabled={!selectedDoctor || !form.preferredDate} value={form.preferredTime} onChange={(event) => update("preferredTime", event.target.value)} />}<span className="form-helper">{selectedDoctor?.schedule.confirmed ? "Times shown are request options, not confirmed slots." : "Unconfirmed schedule: hospital staff will review your preferred time."}</span></div>
    <div className="form-group form-group-full"><label className="form-label" htmlFor="book-reason">Reason for consultation <span>*</span></label><textarea className="form-input form-textarea" id="book-reason" name="reason" placeholder="Briefly describe what you would like to discuss" required minLength={5} maxLength={2000} value={form.reason} onChange={(event) => update("reason", event.target.value)} /></div>
    <div className="form-group form-group-full"><label className="form-label" htmlFor="book-notes">Additional notes <span className="!text-[#8396a4]">(optional)</span></label><textarea className="form-input form-textarea" id="book-notes" name="notes" placeholder="Anything else you would like the appointment team to know?" maxLength={3000} value={form.notes} onChange={(event) => update("notes", event.target.value)} /></div>
    <div className="honeypot" aria-hidden="true"><label htmlFor="book-website">Website</label><input id="book-website" name="website" tabIndex={-1} autoComplete="off" value={form.website} onChange={(event) => update("website", event.target.value)} /></div></div>
    {error && <div className="form-alert" role="alert">{error}</div>}
    <div className="form-submit-row"><p className="form-note">By submitting, you are sending an appointment <strong>request</strong>. The hospital must confirm your visit. Do not include sensitive medical records in this form.</p><button className="btn btn-primary" type="submit" disabled={busy}>{busy ? "Sending Request..." : "Submit Appointment Request"} <ArrowUpRight size={16} /></button></div>
    <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-3 border-t border-[#DCEAE2] pt-5 text-[11px] text-[#667B78]"><span>Prefer to speak to us?</span><a href={whatsappHref} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 font-bold text-[#087F78]"><FaWhatsapp size={17} /> Continue on WhatsApp <ArrowUpRight size={13} /></a><a href={phoneToHref(settings.phone)} className="inline-flex items-center gap-2 font-bold text-[#087F78]"><Phone size={15} /> Call {settings.phone}</a></div>
  </form>;
}
