import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Lazy, optional database connection.
 *
 * - Nothing connects at import/build time, so `next build` works without any env vars.
 * - If DATABASE_URL is missing, public pages still render from the built-in content and
 *   only the forms / staff dashboard report "database not configured".
 * - Tables are created automatically on first use (no manual migration step needed).
 */

export class DatabaseNotConfiguredError extends Error {
  constructor() {
    super("DATABASE_URL is not configured");
    this.name = "DatabaseNotConfiguredError";
  }
}

export const databaseConfigured = () => Boolean(process.env.DATABASE_URL);

const SCHEMA_SQL = `
create extension if not exists pgcrypto;

create table if not exists appointment_requests (
  id uuid primary key default gen_random_uuid(),
  reference varchar(40) not null unique,
  patient_name varchar(160) not null,
  phone varchar(30) not null,
  age integer not null,
  gender varchar(40) not null,
  specialty_slug varchar(120) not null,
  doctor_slug varchar(120) not null,
  preferred_date varchar(10) not null,
  preferred_time varchar(5) not null,
  reason text not null,
  notes text not null default '',
  status varchar(24) not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists appointment_status_idx on appointment_requests (status);
create index if not exists appointment_created_idx on appointment_requests (created_at);

create table if not exists contact_enquiries (
  id uuid primary key default gen_random_uuid(),
  name varchar(160) not null,
  email varchar(200) not null,
  phone varchar(30) not null,
  subject varchar(200) not null,
  message text not null,
  status varchar(24) not null default 'new',
  created_at timestamptz not null default now()
);
create index if not exists enquiry_created_idx on contact_enquiries (created_at);

create table if not exists content_overrides (
  key varchar(180) primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
`;

type Globals = typeof globalThis & {
  __hmcPool?: Pool;
  __hmcDb?: NodePgDatabase;
  __hmcReady?: Promise<void>;
  __hmcDownUntil?: number;
};
const g = globalThis as Globals;

function getPool() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new DatabaseNotConfiguredError();
  if (!g.__hmcPool) {
    g.__hmcPool = new Pool({
      connectionString: url,
      // Small pool: friendly to serverless platforms and free-tier databases (Neon, Supabase).
      max: 3,
      idleTimeoutMillis: 10_000,
      connectionTimeoutMillis: 8_000,
    });
    g.__hmcPool.on("error", (error) => console.error("Postgres pool error:", error.message));
  }
  return g.__hmcPool;
}

/** Returns a ready-to-use Drizzle client, creating the tables on first use. */
export async function getDb(): Promise<NodePgDatabase> {
  const pool = getPool();
  // After a connection failure, fail fast for a short while so public pages
  // (which fall back to built-in content) are not slowed down by repeated timeouts.
  if (g.__hmcDownUntil && g.__hmcDownUntil > Date.now()) throw new Error("Database temporarily unavailable");
  if (!g.__hmcDb) g.__hmcDb = drizzle(pool);
  if (!g.__hmcReady) {
    g.__hmcReady = pool.query(SCHEMA_SQL).then(() => { g.__hmcDownUntil = undefined; }).catch((error) => {
      g.__hmcReady = undefined; // retry later instead of caching the failure
      g.__hmcDownUntil = Date.now() + 15_000;
      console.error("Database connection/setup failed:", error instanceof Error ? error.message : error);
      throw error;
    });
  }
  await g.__hmcReady;
  return g.__hmcDb;
}
