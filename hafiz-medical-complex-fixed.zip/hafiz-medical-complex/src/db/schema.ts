import { index, integer, jsonb, pgTable, text, timestamp, uuid, varchar } from "drizzle-orm/pg-core";

export const appointmentRequests = pgTable("appointment_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  reference: varchar("reference", { length: 40 }).notNull().unique(),
  patientName: varchar("patient_name", { length: 160 }).notNull(),
  phone: varchar("phone", { length: 30 }).notNull(),
  age: integer("age").notNull(),
  gender: varchar("gender", { length: 40 }).notNull(),
  specialtySlug: varchar("specialty_slug", { length: 120 }).notNull(),
  doctorSlug: varchar("doctor_slug", { length: 120 }).notNull(),
  preferredDate: varchar("preferred_date", { length: 10 }).notNull(),
  preferredTime: varchar("preferred_time", { length: 5 }).notNull(),
  reason: text("reason").notNull(),
  notes: text("notes").notNull().default(""),
  status: varchar("status", { length: 24 }).notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("appointment_status_idx").on(table.status), index("appointment_created_idx").on(table.createdAt)]);

export const contactEnquiries = pgTable("contact_enquiries", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 30 }).notNull(),
  subject: varchar("subject", { length: 200 }).notNull(),
  message: text("message").notNull(),
  status: varchar("status", { length: 24 }).notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("enquiry_created_idx").on(table.createdAt)]);

export const contentOverrides = pgTable("content_overrides", {
  key: varchar("key", { length: 180 }).primaryKey(),
  value: jsonb("value").$type<Record<string, unknown>>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});
