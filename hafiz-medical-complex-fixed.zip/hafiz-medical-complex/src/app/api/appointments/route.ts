import { randomBytes } from "node:crypto";
import { z } from "zod";
import { DatabaseNotConfiguredError, getDb } from "@/db";
import { appointmentRequests } from "@/db/schema";
import { currentTimeInPakistan, isVisitingDay, timeSlots, todayInPakistan, validDate } from "@/lib/appointment-utils";
import { getDoctors, getSpecialties } from "@/lib/content-db";

export const dynamic = "force-dynamic";

const requestSchema = z.object({
  patientName: z.string().trim().min(2).max(160),
  phone: z.string().trim().regex(/^\+?[\d\s()-]{9,24}$/, "Enter a valid mobile number."),
  age: z.number().int().min(1).max(120),
  gender: z.enum(["Female", "Male", "Other", "Prefer not to say"]),
  specialtySlug: z.string().min(1).max(120),
  doctorSlug: z.string().min(1).max(120),
  preferredDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  preferredTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),
  reason: z.string().trim().min(5).max(2000),
  notes: z.string().trim().max(3000).default(""),
  website: z.string().max(0).optional(),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = requestSchema.safeParse(body);
    if (!parsed.success) return Response.json({ error: "Please check the form fields and try again.", details: parsed.error.flatten().fieldErrors }, { status: 400 });
    const data = parsed.data;
    const [doctors, specialties] = await Promise.all([getDoctors(), getSpecialties()]);
    const doctor = doctors.find((item) => item.slug === data.doctorSlug);
    const specialty = specialties.find((item) => item.slug === data.specialtySlug);
    if (!doctor || !specialty || !doctor.specialtySlugs.includes(specialty.slug)) return Response.json({ error: "Please choose a doctor who consults in the selected specialty." }, { status: 400 });
    if (!validDate(data.preferredDate) || data.preferredDate < todayInPakistan()) return Response.json({ error: "Please choose a valid future appointment date." }, { status: 400 });
    if (!isVisitingDay(data.preferredDate, doctor.schedule)) return Response.json({ error: "The selected doctor does not have published visiting hours on that day. Please choose another date." }, { status: 400 });
    if (doctor.schedule.confirmed && !timeSlots(doctor.schedule).includes(data.preferredTime)) return Response.json({ error: "Please choose a time within the doctor's published consultation hours." }, { status: 400 });
    if (data.preferredDate === todayInPakistan() && data.preferredTime <= currentTimeInPakistan()) return Response.json({ error: "Please choose a future time for today or a later visiting date." }, { status: 400 });
    const reference = `HMC-${new Date().toISOString().slice(2, 10).replace(/-/g, "")}-${randomBytes(4).toString("hex").toUpperCase()}`;
    const db = await getDb();
    await db.insert(appointmentRequests).values({ reference, patientName: data.patientName, phone: data.phone, age: data.age, gender: data.gender, specialtySlug: data.specialtySlug, doctorSlug: data.doctorSlug, preferredDate: data.preferredDate, preferredTime: data.preferredTime, reason: data.reason, notes: data.notes, status: "pending" });
    return Response.json({ ok: true, reference, status: "pending", doctorName: doctor.name, specialtyName: specialty.title, preferredDate: data.preferredDate, preferredTime: data.preferredTime }, { status: 201 });
  } catch (error) {
    if (error instanceof SyntaxError) return Response.json({ error: "Invalid request." }, { status: 400 });
    console.error("Appointment request failed:", error instanceof Error ? error.message : error);
    return Response.json({ error: "We could not save your request right now. Please call or WhatsApp the hospital instead." }, { status: error instanceof DatabaseNotConfiguredError ? 503 : 500 });
  }
}
