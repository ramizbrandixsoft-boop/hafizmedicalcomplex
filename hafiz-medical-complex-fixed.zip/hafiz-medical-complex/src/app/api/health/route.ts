import { sql } from "drizzle-orm";
import { databaseConfigured, getDb } from "@/db";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!databaseConfigured()) return Response.json({ ok: true, database: "not-configured" });
  try {
    const db = await getDb();
    await db.execute(sql`select 1`);
    return Response.json({ ok: true, database: "connected" });
  } catch {
    return Response.json({ ok: false, database: "unreachable" }, { status: 503 });
  }
}
