import { cookies } from "next/headers";
import { z } from "zod";
import { ADMIN_COOKIE, adminConfigured, adminCookieOptions, createAdminSession, validAdminPassword } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";
const attempts = new Map<string, { count: number; resetAt: number }>();

export async function POST(request: Request) {
  if (!adminConfigured()) return Response.json({ error: "Staff access is not configured on this server." }, { status: 503 });
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  const now = Date.now();
  const previous = attempts.get(ip);
  if (previous && previous.resetAt > now && previous.count >= 8) return Response.json({ error: "Too many attempts. Please try again later." }, { status: 429 });
  let payload: unknown;
  try { payload = await request.json(); } catch { return Response.json({ error: "Invalid request." }, { status: 400 }); }
  const parsed = z.object({ password: z.string().min(1).max(300) }).safeParse(payload);
  if (!parsed.success || !validAdminPassword(parsed.data.password)) {
    attempts.set(ip, { count: previous && previous.resetAt > now ? previous.count + 1 : 1, resetAt: previous && previous.resetAt > now ? previous.resetAt : now + 15 * 60 * 1000 });
    return Response.json({ error: "Incorrect password." }, { status: 401 });
  }
  attempts.delete(ip);
  (await cookies()).set(ADMIN_COOKIE, createAdminSession(), adminCookieOptions);
  return Response.json({ ok: true });
}
