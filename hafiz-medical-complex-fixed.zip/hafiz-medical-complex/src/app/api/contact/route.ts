import { z } from "zod";
import { DatabaseNotConfiguredError, getDb } from "@/db";
import { contactEnquiries } from "@/db/schema";

export const dynamic = "force-dynamic";

const contactSchema = z.object({
  name: z.string().trim().min(2).max(160),
  email: z.email().max(200),
  phone: z.string().trim().regex(/^\+?[\d\s()-]{9,24}$/, "Enter a valid phone number."),
  subject: z.string().trim().min(3).max(200),
  message: z.string().trim().min(10).max(3000),
  website: z.string().max(0).optional(),
});

export async function POST(request: Request) {
  try {
    let payload: unknown;
    try { payload = await request.json(); } catch { return Response.json({ error: "Invalid request." }, { status: 400 }); }
    const parsed = contactSchema.safeParse(payload);
    if (!parsed.success) return Response.json({ error: "Please complete all fields with valid contact information." }, { status: 400 });
    const { name, email, phone, subject, message } = parsed.data;
    const db = await getDb();
    await db.insert(contactEnquiries).values({ name, email, phone, subject, message, status: "new" });
    return Response.json({ ok: true, message: "Your enquiry has been received." }, { status: 201 });
  } catch (error) {
    console.error("Contact enquiry failed:", error instanceof Error ? error.message : error);
    return Response.json({ error: "We could not save your message right now. Please call or email the hospital instead." }, { status: error instanceof DatabaseNotConfiguredError ? 503 : 500 });
  }
}
