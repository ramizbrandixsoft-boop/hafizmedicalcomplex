import Link from "next/link";
import { ArrowUpRight, CalendarDays, HeartHandshake, Search } from "lucide-react";
import { CalloutCTA, PageHero, SectionHeading, SpecialtyCard } from "@/components/ui";
import { getSpecialties } from "@/lib/content-db";
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata("Medical Specialties", "Explore medical specialties at HAFIZ Medical Complex in Daska, including general medicine, surgery, diabetes care, women's health, ENT and more.", "/specialties");

export default async function SpecialtiesPage() {
  const specialties = await getSpecialties();
  return <><PageHero eyebrow="EXPERTISE ACROSS SPECIALTIES" title="Care That Meets You Where You Are." description="Discover the consultation areas listed at HAFIZ Medical Complex. Find out what each specialty covers and connect with a relevant doctor in Daska." image="/images/family-south-asian.jpg" imageAlt="Illustrative South Asian family doctor consultation; not HAFIZ staff" breadcrumbs={[{ label: "Medical Specialties" }]} />
    <section className="section-space"><div className="container-site"><SectionHeading eyebrow="EXPLORE DEPARTMENTS" title="Find the care you're looking for." description="From everyday health concerns to more focused specialist questions, explore our listed consultation areas below." /><div className="specialty-grid">{specialties.map((specialty, index) => <SpecialtyCard key={specialty.slug} specialty={specialty} index={index} />)}</div></div></section>
    <section className="section-space section-soft"><div className="container-site"><SectionHeading eyebrow="NOT SURE WHERE TO START?" title="A simple path to the right specialist." /><div className="simple-card-grid"><article className="simple-card"><span className="simple-card-icon"><Search size={22} /></span><h3>Explore a specialty</h3><p>Each specialty page explains common concerns in patient-friendly language and shows relevant doctors.</p></article><article className="simple-card"><span className="simple-card-icon"><HeartHandshake size={22} /></span><h3>Ask for guidance</h3><p>If you are unsure who to see, contact the hospital appointment team for help finding a starting point.</p></article><article className="simple-card"><span className="simple-card-icon"><CalendarDays size={22} /></span><h3>Request a visit</h3><p>Choose your preferred doctor and time. Your online request remains pending until staff confirms it.</p></article></div><div className="mt-8 text-center"><Link href="/doctors" className="btn btn-outline">Browse Our Doctors <ArrowUpRight size={17} /></Link></div></div></section>
    <CalloutCTA />
  </>;
}
