import Link from "next/link";
import { ArrowUpRight, Camera, Info } from "lucide-react";
import { GalleryGrid } from "@/components/gallery-grid";
import { CalloutCTA, PageHero, SectionHeading } from "@/components/ui";
import { getGallery } from "@/lib/content-db";
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata("Gallery", "Explore illustrative healthcare imagery and gallery categories for HAFIZ Medical Complex. Placeholder images are clearly labelled and can be replaced with genuine hospital photographs.", "/gallery");

export default async function GalleryPage() {
  const items = await getGallery();
  return <><PageHero eyebrow="VISUAL GALLERY" title="A Closer Look at Care." description="Browse gallery categories for the hospital, medical team and patient care. Genuine hospital photography can be added as it becomes available." image="/images/team-south-asian.jpg" imageAlt="Illustrative South Asian medical team; not HAFIZ staff" breadcrumbs={[{ label: "Gallery" }]} />
    <section className="section-space"><div className="container-site"><SectionHeading eyebrow="EXPLORE THE GALLERY" title="Moments that matter." description="Select a category or open an image for a closer view." /><div className="mb-8 flex items-start gap-3 rounded-xl border border-[#d8e8ef] bg-[#F2F8F3] p-5 text-[#4a7087]"><Info size={19} className="mt-0.5 shrink-0" /><p className="m-0 text-[12px] leading-6"><strong>Photography notice:</strong> These design illustrations and stock placeholders are not photographs of HAFIZ Medical Complex, its doctors, staff or facilities. Hospital management can replace them with genuine photographs in the staff dashboard.</p></div><GalleryGrid items={items} /></div></section>
    <section className="section-space section-soft"><div className="container-site grid items-center gap-7 rounded-[20px] border border-[#D7E8DB] bg-white p-8 md:grid-cols-[auto_1fr_auto] md:p-10"><span className="grid h-16 w-16 place-items-center rounded-2xl bg-[#E7F3EA] text-[#087F78]"><Camera size={28} /></span><div><h2 className="mb-2 text-[24px] font-bold text-[#183D3D]">Come see us in Daska.</h2><p className="m-0 text-[12px] leading-6 text-[#667B78]">Find the hospital at Milad Chowk, College Road. Get directions or call ahead to plan your visit.</p></div><Link href="/contact" className="btn btn-primary">Find Us <ArrowUpRight size={17} /></Link></div></section>
    <CalloutCTA />
  </>;
}
