import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { SiteFooter, SiteHeader } from "@/components/site-shell";
import { getSiteSettings } from "@/lib/content-db";
import { clinicStructuredData, siteUrl } from "@/lib/seo";
import "./globals.css";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: "HAFIZ Medical Complex | Specialist Healthcare in Daska", template: "%s | HAFIZ Medical Complex Daska" },
  description: "Explore specialist doctors, medical specialties and appointment requests at HAFIZ Medical Complex, Milad Chowk, College Road, Daska.",
  applicationName: "HAFIZ Medical Complex",
  keywords: ["HAFIZ Medical Complex Daska", "hospital in Daska", "doctors in Daska", "specialist doctors in Daska"],
  robots: { index: true, follow: true },
};

export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#087F78" };

export default async function RootLayout({ children }: { children: ReactNode }) {
  const settings = await getSiteSettings();
  const jsonLd = JSON.stringify(clinicStructuredData(settings)).replace(/</g, "\\u003c");
  const previewThemeScript = "(function(){var t;try{var q=new URLSearchParams(location.search).get('theme');if(q==='classic'||q==='teal'){t=q;sessionStorage.setItem('hmc-demo-theme',t)}else{t=sessionStorage.getItem('hmc-demo-theme')}}catch(e){t=new URLSearchParams(location.search).get('theme')}if(t==='classic'||t==='teal'){document.documentElement.setAttribute('data-demo-theme',t);document.documentElement.setAttribute('data-preview-variant',t)}})();";
  return <html lang="en" suppressHydrationWarning><head><script dangerouslySetInnerHTML={{ __html: previewThemeScript }} /></head><body><SiteHeader settings={settings} /><main id="main-content">{children}</main><SiteFooter settings={settings} /><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd }} /></body></html>;
}
